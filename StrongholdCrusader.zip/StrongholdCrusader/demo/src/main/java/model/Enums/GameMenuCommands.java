package model.Enums;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum GameMenuCommands {


    SELECT_UNIT("(?=.* -x (?<x>-?\\d+))(?=.* -y (?<y>-?\\d+))(?=.* -t (?<unitType>(\"[^\"]*\")|(\\S+)))" +
            "^select unit( -[xyt] ((\"[^\"]*\")|(\\S+))){2,3}$"),
    MOVE_UNIT("(?=.* -x (?<x>-?\\d+))(?=.* -y (?<y>-?\\d+))^move unit to( -[xy] -?\\d+){2}$"),
//    PATROL_UNIT("(?=.* -x (?<x>-?\\d+))(?=.* -y (?<y>-?\\d+))^patrol unit( -[xy] \\d+){2}$"),
    PATROL_UNIT("^patrol unit -x1 (?<x1>-?\\d+) -y1 (?<y1>-?\\d+)" +
        " -x2 (?<x2>-?\\d+) -y2 (?<y2>-?\\d+)$"),
    SET_STATE("^set -x (?<x>-?\\d+) -y (?<y>-?\\d+) -s (?<mode>\\S+)$"),
    SHOWMAPCOORDINATED("^show map -x (?<x>-?\\d+) -y (?<y>-?\\d+)$"),
    ATTACK("^attack -e (?<xEnemy>-?\\d+) (?<yEnemy>-?\\d+)$"),
    POUR_OIL("^pour oil -d (?<direction>\\S+)$"),
    OPEN_TRADE_MENU("^open trade menu$"),
    OPEN_SHOP_MENU("^open shop menu$"),
    STOP_PATROL("^stop patrol$"),

    ATTACK_ARCHER("(?=.* -x (?<x>-?\\d+))(?=.* -y (?<y>-?\\d+))^attack( -[xy] \\d+){2}$"),
    DIG_TUNNEL("(?=.* -x (?<x>-?\\d+))(?=.* -y (?<y>-?\\d+))^dig tunnel( -[xy] \\d+){2}$"),
    FILL_MOAT("fill moat -x (?<x>-?\\d+) -y (?<y>-?\\d+}$"),
    DIG_MOAT("dig moat -x (?<x>-?\\d+) -y (?<y>-?\\d+}$"),
    STOP("^stop$"),
    BUILD("^build -q (?<equipmentType>(\"[^\"]*\")|(\\S+))$"),
    DISBAND("^disband unit$"),

    ;
    final String regex;

    public String getRegex() {
        return regex;
    }

    GameMenuCommands(String regex) {
        this.regex = regex;
    }

    public static Matcher getMatcher(String command, GameMenuCommands Regex) {
        return Pattern.compile(Regex.regex).matcher(command);
    }
}

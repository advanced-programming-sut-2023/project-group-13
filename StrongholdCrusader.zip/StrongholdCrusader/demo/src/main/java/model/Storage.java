package model;

public class Storage {
}

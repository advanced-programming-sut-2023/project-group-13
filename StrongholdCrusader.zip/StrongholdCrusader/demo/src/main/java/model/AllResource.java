package model;

public enum AllResource {
    WOOD("Wood" , 6 , 3 , "stockpile"),
    IRON("Iron" , 40 , 25 , "stockpile"),
    STONE("Stone", 30 , 15 , "stockpile"),
    ALE("Ale", 20 , 12 , "stockpile"),
    PITCH("Pitch", 25 , 14 , "stockpile"),
    HOPS("Hops", 25 , 14 , "stockpile"),
    FLOUR("Flour", 40 , 25 , "stockpile"),
    WHEAT("Wheat", 40 , 25 , "stockpile"),
    BREAD("Bread" , 40 , 20 , "granary"),
    APPLE("Apple", 40 , 20 , "granary"),
    CHEESE("Cheese", 40 , 20 , "granary"),
    MEAT("Meat", 40 , 20 , "granary"),
    METALARMOUR("MetalArmour", 40 , 20 , "armoury"),
    LEATHERARMOUR("LeatherArmour",40 , 20 , "armoury"),
    CROSSBOW("CrossBow",40 , 20 , "armoury"),
    MACE("Mace",40 , 20 , "armoury"),
    PIKE("Pike",40 , 20 , "armoury"),
    SWORD("Sword",40 , 20 , "armoury"),
    BOW("Bow",40 , 20 , "armoury"),
    SPEAR("Spear",40 , 20 , "armoury");
    private String resourceName;
    int buy;
    int sell;
    String category;

    AllResource(String resourceName , int buy , int sell , String category ) {
        this.resourceName = resourceName;
        this.buy = buy;
        this.sell = sell;
        this.category = category;
    }

    public int getBuy() {
        return buy;
    }

    public int getSell() {
        return sell;
    }

    public String getCategory() {
        return category;
    }

    public String getResourceName() {
        return resourceName;
    }
}

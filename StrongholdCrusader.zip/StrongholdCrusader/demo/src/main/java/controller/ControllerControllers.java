package controller;

import javafx.stage.Stage;
import model.Enums.DataEnumFile;
import model.Player;
import model.SaveAndLoadData;
import view.beforechange.*;
import view.menus.LoginMenuG;
import view.menus.MainMenuG;

import java.io.File;
import java.util.ArrayList;

public class ControllerControllers {
    public static Stage stage;
    private final LoginMenu loginMenu;
    private final MainMenu mainMenu;
    private final SignupMenu signupMenu;
    private final MapMenu mapMenu;
    private final ProfileMenu profileMenu;
    private final view.beforechange.RunGameMenu RunGameMenu;
    private final MapMenuController mapMenuController;
    public ControllerControllers() {
        loginMenu = new LoginMenu(this);
        mainMenu = new MainMenu(this);
        signupMenu = new SignupMenu(this);
        profileMenu = new ProfileMenu(this);
        mapMenu = new MapMenu(this);
        mapMenuController = new MapMenuController(this);
        mapMenu.setMapMenuController(mapMenuController);
        RunGameMenu = new RunGameMenu(this);
    }
    public void run() throws Exception {
        File file = new File(DataEnumFile.PLAYERS.getFileName());
        if (file.exists()) {
            Player.players = SaveAndLoadData.LoadData(DataEnumFile.PLAYERS.getFileName(),
                    DataEnumFile.PLAYERS.getDataType());
        }
        if (Player.players == null) {
            Player.players = new ArrayList<>();
        }

      if (Player.players != null) {
            for (Player temp : Player.players) {
                if (temp.getLoggedIn()) Player.setCurrentPlayer(temp);
                break;
            }
       }

        if (Player.getCurrentPlayer() == null) {
            new LoginMenuG().start(stage);
        }
        else new MainMenuG().start(stage);


    }


}

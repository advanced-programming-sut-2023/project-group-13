package controller;

import view.menus.LoginMenuG;
import view.menus.ProfileMenuG;

public class MainMenuController {

   public static void logout() throws Exception {
       LoginMenuG loginMenuG = new LoginMenuG();
       loginMenuG.start(LoginMenuG.stage);
   }
   public static void profileMenu() throws Exception {
       ProfileMenuG profileMenuG = new ProfileMenuG();
       profileMenuG.start(LoginMenuG.stage);
   }

}

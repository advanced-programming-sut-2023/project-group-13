package controller;

public class MainMenuController {
    public void showAllMenus() {
        System.out.println("map menu --> enter map menu");
        System.out.println("login menu --> logout");
        System.out.println("sign up menu --> you can go to it from login menu");
        System.out.println("profile menu --> enter profile menu");
        System.out.println("run game menu --> run a new game");
        System.out.println("new game menu --> go to it from RunGameMenu menu with command: start a new game");
        System.out.println("game menu --> go to it from NewGameMenu with command: start a new game");
        System.out.println("kingdom menu --> go to it from game menu with command: kingdom menu");
    }
}

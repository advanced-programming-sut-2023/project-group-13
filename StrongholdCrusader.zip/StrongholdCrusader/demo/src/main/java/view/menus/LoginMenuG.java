package view.menus;

import controller.ControllerControllers;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.stage.Screen;
import javafx.stage.Stage;
import model.Enums.DataEnumFile;
import model.Player;
import model.SaveAndLoadData;
import view.controller.LoginMenuController;


public class LoginMenuG extends Application {
    public static Stage stage;

    @FXML
    private TextField u1;
    @FXML
    private PasswordField p1;
    @FXML
    private Label labelUsername;
    @FXML
    private Label labelPassword;
    @FXML
    private CheckBox c1;
    private Player player;



    @Override
    public  void start(Stage stage) throws Exception {

        LoginMenuG.stage = stage;
        ControllerControllers.stage = stage;


        Pane pane =  new FXMLLoader(LoginMenuG.class.getResource("/fxml/LoginMenu.fxml")).load();
        Image background = new Image(LoginMenuG.class.getResource("/png/mainmenu.jpg").toExternalForm());

        stage.setTitle("LoginMenu!");
        BackgroundImage x = new BackgroundImage(background,
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
        pane.setBackground(new javafx.scene.layout.Background(x));
        Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();

        Scene scene = new Scene(pane, screenBounds.getWidth(), screenBounds.getHeight());

        stage.setScene(scene);
        stage.setMaximized(true);
        stage.setResizable(true);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
    @FXML
    public void initialize() throws Exception {

            u1.textProperty().addListener((observable, oldValue, newValue) -> {
                labelUsername.setText("");
                player = Player.getPlayerByUsername(newValue);
                if (player == null) {
                    labelUsername.setText("user not found.");
                } else labelUsername.setText("ok!");
            });

            p1.textProperty().addListener((observable, oldValue, newValue) -> {

                labelPassword.setText("");
                if (player.getPassword().equals(newValue)) {
                    labelPassword.setText("invalid password.");
                } else labelPassword.setText("ok!");
            });

            if (labelPassword.getText().equals("ok!") && labelUsername.getText().equals("ok!")) {
                if (c1.isSelected()) {
                    for (Player players : Player.players) {
                        players.setLoggedIn(false);
                    }
                    player.setLoggedIn(true);
                    Player.setCurrentPlayer(player);
                    SaveAndLoadData.SaveToJson(Player.players, DataEnumFile.PLAYERS.getFileName());
                    MainMenuG mainMenu = new MainMenuG();
                    mainMenu.start(LoginMenuG.stage);
                } else {
                    Player.setCurrentPlayer(player);
                    MainMenuG mainMenu = new MainMenuG();
                    mainMenu.start(LoginMenuG.stage);
                }
            }
    }
}

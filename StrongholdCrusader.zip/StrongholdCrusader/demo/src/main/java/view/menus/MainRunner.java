package view.menus;

import controller.ControllerControllers;
import javafx.application.Application;
import javafx.stage.Stage;

public class MainRunner extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        ControllerControllers controllerControllers = new ControllerControllers();
        ControllerControllers.stage = stage;
        controllerControllers.run();
    }
}

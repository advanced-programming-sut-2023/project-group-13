//package view;
//
//import model.Map;
//
//import java.util.regex.Matcher;
//
//public class LoadGameMenu {
//    private Matcher matcher;
//    public void run() {
//        String command;
//        System.out.println();
//    }
//}

package view.controller;

import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import model.Enums.DataEnumFile;
import model.Enums.SignupMenuCommands;
import model.Player;
import model.RandomsAndCaptcha;
import model.SaveAndLoadData;
import view.beforechange.ScannerMatcher;
import view.menus.LoginMenuG;

import java.util.Scanner;

public class SignupMenuController {
    public void loginMenu(MouseEvent mouseEvent) throws Exception {
        LoginMenuG loginMenuG = new LoginMenuG();
        loginMenuG.start(LoginMenuG.stage);
    }
}


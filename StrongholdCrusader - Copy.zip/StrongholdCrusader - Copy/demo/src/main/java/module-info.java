module com.example.demo {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;
   // requires javafx.media;



    exports controller;
    exports model;

    opens controller to javafx.fxml;
    opens model to javafx.fxml;
    exports view.controller;
    opens view.controller to javafx.fxml;
    exports view.menus;
    opens view.menus to javafx.fxml;
    exports view.beforechange;
    opens view.beforechange to javafx.fxml;


}
package controller;

import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import model.Enums.DataEnumFile;
import model.Enums.LoginMenuCommands;
import model.Player;
import model.RandomsAndCaptcha;
import model.SaveAndLoadData;
import view.beforechange.ScannerMatcher;
import view.menus.LoginMenuG;
import view.menus.MainMenuG;

import java.util.regex.Matcher;

public class LoginMenuController {
    @FXML
    private static PasswordField p1;
    @FXML
    private static TextField u1;
    @FXML
    private static Text l1;
    @FXML
    private static CheckBox c1;


    public static void forgotPassword(Matcher matcher) {
        String username = u1.getText();
        Player player = Player.getPlayerByUsername(username);
        if (player == null) l1.setText("user not found");
        ;
        System.out.println(Player.securityQuestions[player.getQuestionNumber() - 1]);
        String answer = ScannerMatcher.getScanner().nextLine();
        if (!answer.equals(player.getSecurityQuestionAnswer())) ;
        //go to main menu
        System.out.println("enter your new password like this with confirmation:-p abc -c abc");
        answer = ScannerMatcher.getScanner().nextLine();
        if (!(matcher = LoginMenuCommands.getMatcher(answer, LoginMenuCommands.CHANGE_PASSWORD_FROM_FORGOT_PASSWORD)).find()) {
            String password = matcher.group("password");
            String passwordConfirmation = matcher.group("passwordConfirmation");
            if (!passwordConfirmation.equals(password)) ;

//            String[] a = RandomsAndCaptcha.captchaGenerator();
//            for (int i = 0; i < a.length; i++) {             // print captcha
//                System.out.print(a[i]);
//            }
//            System.out.println("\nplease enter the captcha numbers.");
            int answerNumber = ScannerMatcher.getScanner().nextInt();
            String temp = ScannerMatcher.getScanner().nextLine();
            if (answerNumber != (Integer.parseInt(RandomsAndCaptcha.getRealNumber()))) {
                RandomsAndCaptcha.setRealNumber("");
                ;
            }
            RandomsAndCaptcha.setRealNumber("");
            player.setPassword(password);
            SaveAndLoadData.SaveToJson(Player.players, DataEnumFile.PLAYERS.getFileName());
            // go to main menu
        }

        ;
    }

    public static void Login() throws Exception {
        String username = u1.getText();
        String password = p1.getText();
        if (username == null || password == null) {
            l1.setText("fill all the fields");
            return;
        }
        Player player = Player.getPlayerByUsername(username);

        if (player == null) {
            l1.setText("user not found");
        } else if (!player.getPassword().equals(password)) {
            l1.setText("wrong password");
        } else {
            if (c1.isSelected()) {
                player.setLoggedIn(true);
                for (Player temp : Player.players) {
                    if (temp != player) temp.setLoggedIn(false);
                }
                SaveAndLoadData.SaveToJson(Player.players, DataEnumFile.PLAYERS.getFileName());
            }
            Player.setCurrentPlayer(player);
            new MainMenuG().start(LoginMenuG.stage);
        }
    }
}

package view.menus;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.Enums.DataEnumFile;
import model.Enums.SignupMenuCommands;
import model.Player;
import model.RandomsAndCaptcha;
import model.SaveAndLoadData;
import view.beforechange.LoginMenu;

import java.util.regex.Pattern;

public class SignupMenuG extends Application {
    private Label labelUsername;
    private Label labelPassword;
    private Label labelPasswordConfirmation;
    private Label labelEmail;
    private Label labelNickname;
    private Label labelSlogan;
    private TextFieldMaker username;
    private TextField email;
    private TextField nickname;
    private TextField slogan;
    private TextField security;
    private Pane pane;

    private PasswordFieldMaker password;
    private PasswordFieldMaker passwordConfirmation;
    private CheckBox father;
    private CheckBox mother;
    private CheckBox pet;
    private Label labelSecurity;
    private Button randomSlogan;
    private Button randomPassword;
    private Button showPassword;
    private Button submit;
    private Button dontHaveAccount;
    private Button forgetPassword;
    private boolean validPassword1;
    private boolean validUsername;
    private boolean validPasswordConfirmation;
    private boolean validEmail;
    private boolean validNickname;
    private ImageView captcha;
    private int captchaNumber;


    @Override
    public void start(Stage stage) throws Exception {
        captcha = new ImageView();

        FXMLLoader fxmlLoader = new FXMLLoader(LoginMenu.class.getResource("/fxml/signupMenu.fxml"));
        pane = fxmlLoader.load();
        pane.getChildren().add(captcha);
        captchaMaking();
        Image background = new Image(LoginMenuG.class.getResource("/png/mainmenu.jpg").toExternalForm());
        BackgroundImage x = new BackgroundImage(background,
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
        pane.setBackground(new javafx.scene.layout.Background(x));
        Scene scene = new Scene(pane);
        stage.setTitle("SignupMenu");
        stage.setMaximized(true);
        stage.setScene(scene);
        stage.show();
    }

    public void submit(MouseEvent mouseEvent) {
        if (validPassword1 && validUsername && validEmail && validPasswordConfirmation ) {

        }

        String usernameS = username.getText();
        String passwordS = password.getText();
        String passwordConfirmationS = passwordConfirmation.getText();
        String sloganS = slogan.getText();
        String emailS = email.getText();
        String nicknameS = nickname.getText();


        int counter = 0;
        if (father.isSelected()) counter++;
        if (mother.isSelected()) counter++;
        if (pet.isSelected()) counter++;

        int questionNumber = 0;
        String answer = "1";

        Player player = new Player(usernameS, passwordS, sloganS, emailS, nicknameS, questionNumber, answer);
        Player.players.add(player);
        SaveAndLoadData.SaveToJson(Player.players, DataEnumFile.PLAYERS.getFileName());

    }


    public void validEmailCheck() {
        username.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observableValue, String oldValue, String newValue) {
                username.clearErrorOrMessage();
                for (Player player : Player.players) {
                    if (player.getEmail().equals(newValue)) {
                        email.setText("this email already used.");
                        return;
                    }
                }
                if (!SignupMenuCommands.getMatcher(newValue, SignupMenuCommands.CHECK_EMAIL).find())
                    email.setText("Invalid email format.");

            }
        });
    }

    @FXML
    public void initialize() {
        username.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent keyEvent) {
                labelUsername.setText("done");
            }
        });

    }

    public void PasswordThings() {
        password = new PasswordFieldMaker(pane, "password", "Password", 0, 85);
        pane.getChildren().add(password);
        validatePassword();

        passwordConfirmation = new PasswordFieldMaker(pane, "confirmation", "Confirmation", 0, 145);
        pane.getChildren().add(passwordConfirmation);
        validateConfirmPassword();

        randomPassword = new ButtonMaker("random password", pane, 75, 205);
        randomPassword.setScaleX(0.6);
        randomPassword.setScaleY(0.6);
        randomPassword.setOnAction(actionEvent -> {
            password.getShowPassword().setSelected(true);
            password.getPasswordTextField().setText(RandomsAndCaptcha.randomPasswordGenerator());
        });
        pane.getChildren().add(randomPassword);
    }

    private void usernameConfirmation() {
        username.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observableValue, String oldValue, String newValue) {
                username.clearErrorOrMessage();
                if (newValue == "") {
                    return;
                }
                if (!newValue.matches("([a-z]|[A-Z]|[0-9]|_)*")) {
                    username.handlingError("invalid username!");

                }
                if (Player.getPlayerByUsername(newValue) != null) {
                    username.handlingError("username already exists!");

                } else {
                    username.handlingCorrect("valid username");

                }
            }
        });
    }

    private void validatePassword() {
        password.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observableValue, String oldValue, String newValue) {
                password.clearErrorOrMessage();
                if (newValue == "") {
                    return;
                }
                if (newValue.contains(" "))
                    password.handlingError("you can't user space!");

                if (newValue.length() < 6)
                    labelPassword.setText("password length is below 6.");
                if (newValue.matches(".*[a-z].*") || !newValue.matches(".*[A-Z].*") || !newValue.matches(".*[0-9].*") || !newValue.matches(".*\\W.*"))
                    labelPassword.setText("password pattern is wrong");
                 else {
                    password.handlingCorrect("strong password");
                }

            }

        });


        password.getPasswordTextField().textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observableValue, String oldValue, String newValue) {
                password.clearErrorOrMessage();
                if (newValue == "") {
                    return;
                }
                if (newValue.contains(" "))
                    password.handlingError("you can't user space!");

                if (newValue.length() < 6)
                    labelPassword.setText("password length is below 6.");
                if (newValue.matches(".*[a-z].*") || !newValue.matches(".*[A-Z].*") || !newValue.matches(".*[0-9].*") || !newValue.matches(".*\\W.*"))
                    labelPassword.setText("password pattern is wrong");
                else
                    password.handlingCorrect("strong password");
            }
        });
    }

    private void validateConfirmPassword() {
        passwordConfirmation.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observableValue, String oldValue, String newValue) {
                passwordConfirmation.clearErrorOrMessage();
                if (newValue == "") {
                    return;
                }
                if (!newValue.equals(password.getText())) {
                    passwordConfirmation.handlingError("passwords don't match!");

                } else {
                    passwordConfirmation.handlingCorrect("passwords match");

                }
            }
        });

        passwordConfirmation.getPasswordTextField().textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observableValue, String oldValue, String newValue) {
                passwordConfirmation.clearErrorOrMessage();
                if (newValue == "") {
                    return;
                }
                if (!newValue.equals(password.getText())) {
                    passwordConfirmation.handlingError("passwords don't match!");

                } else {
                    passwordConfirmation.handlingCorrect("passwords match");

                }
            }
        });
    }
    public void captchaMaking() {
        String x = RandomsAndCaptcha.captchaGenerator();
        captcha.setImage(new Image("../resources/png/captcha/" + x +"png"));
        captchaNumber = Integer.parseInt(x);
    }
}

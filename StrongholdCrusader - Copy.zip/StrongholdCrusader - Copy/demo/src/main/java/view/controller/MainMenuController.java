package view.controller;

import controller.ControllerControllers;
import javafx.scene.input.MouseEvent;
import view.menus.LoginMenuG;
import view.menus.ProfileMenuG;

public class MainMenuController {

    public void logout(MouseEvent mouseEvent) throws Exception {
        new LoginMenuG().start(LoginMenuG.stage);
    }

    public void mapMenu(MouseEvent mouseEvent) {
    }

    public void newGame(MouseEvent mouseEvent) {
    }

    public void profileMenu(MouseEvent mouseEvent) throws Exception {
        new ProfileMenuG().start(ControllerControllers.stage);
    }
}

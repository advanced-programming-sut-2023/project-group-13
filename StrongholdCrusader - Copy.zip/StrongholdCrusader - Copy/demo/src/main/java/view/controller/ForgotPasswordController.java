package view.controller;

public class ForgotPasswordController {

}

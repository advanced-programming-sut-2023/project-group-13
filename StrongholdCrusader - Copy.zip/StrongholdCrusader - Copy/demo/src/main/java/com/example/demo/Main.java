package com.example.demo;


import controller.ControllerControllers;

public class Main {
    public static void main(String[] args) throws Exception {

        ControllerControllers controllerControllers = new ControllerControllers();
        controllerControllers.run();
    }
}

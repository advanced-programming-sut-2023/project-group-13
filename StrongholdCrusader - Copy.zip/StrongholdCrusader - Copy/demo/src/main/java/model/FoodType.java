package model;

public enum FoodType {
    MEAT,
    APPLES,
    CHEESE,
    BREAD;
}

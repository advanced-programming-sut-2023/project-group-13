package model.Enums;

import java.util.Scanner;

public class GetScanner {
    private static final Scanner scanner = new Scanner(System.in);
    public static Scanner getScanner(){
        return scanner;
    }
}
